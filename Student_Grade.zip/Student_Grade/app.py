from flask import Flask, render_template, request

app = Flask(__name__)

grade_priority = {
    "A+": 1, "A": 2, "B+": 3, "B": 4, "C": 5, "D": 6, "F": 7
}

def get_grade(percentage):
    if percentage >= 90:
        return "A+", "Pass"
    elif percentage >= 80:
        return "A", "Pass"
    elif percentage >= 70:
        return "B+", "Pass"
    elif percentage >= 60:
        return "B", "Pass"
    elif percentage >= 50:
        return "C", "Pass"
    elif percentage >= 40:
        return "D", "Pass"
    else:
        return "F", "Fail"

@app.route("/", methods=["GET", "POST"])
def index():
    students = []

    if request.method == "POST":
        names = request.form.getlist("name")
        m1 = request.form.getlist("m1")
        m2 = request.form.getlist("m2")
        m3 = request.form.getlist("m3")
       

        for i in range(len(names)):
            marks = [
                int(m1[i]), int(m2[i]), int(m3[i])
            ]
            total = sum(marks)
            percentage = round((total / 300) * 100, 2)
            grade, result = get_grade(percentage)

            students.append({
                "name": names[i],
                "total": total,
                "percentage": percentage,
                "grade": grade,
                "result": result
            })

        students.sort(key=lambda x: grade_priority[x["grade"]])

    return render_template("index.html", students=students)

if __name__ == "__main__":
    app.run(debug=True)
